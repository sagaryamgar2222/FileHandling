﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandling
{
    internal class Files
    {
        internal static void show()
        {
            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            desktop = desktop + "\\Myfile.txt";
            Console.WriteLine(desktop);
            try
            {
                File.ReadAllLines(desktop);
            }
            catch
            {
                File.WriteAllText(desktop, " ");

            }
            ///1---add
            Console.WriteLine("enter text in file");
            string content = Console.ReadLine();
            String[] a = File.ReadAllLines(desktop);
            bool Temp = true;
            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] == content)
                    Temp = false;

            }
            if (Temp)
                File.AppendAllText(desktop, "\r\n" + content);
            else
                Console.WriteLine("already present");

            //2--Search 
            String[] a1 = File.ReadAllLines(desktop);
            Console.WriteLine("enter text for search");
            string serchValue = Console.ReadLine().ToLower();
            bool temp1 = false;
            for (int i = 0; i < a1.Length; i++)
            {
                if (a1[i] == serchValue)
                    temp1 = true;
            }
            if (temp1)
                Console.WriteLine("serached value is present");

            //3--.list All
            String[] a2 = File.ReadAllLines(desktop);
            Console.WriteLine("list of texts");
            foreach (string s in a2)
            {
                Console.WriteLine(s);
            }

            //4--Flex search
            String[] a3 = File.ReadAllLines(desktop);
            Console.WriteLine("enter the text to be search");
            string check = Console.ReadLine().ToLower().Trim();
            bool isContains = false;
            for (int i = 0; i <a3.Length; i++)
            {
                if (a3[i] == check)
                {
                    isContains = true;
                }

            }
            if (isContains)
                Console.WriteLine($"{check} is persent ");


            Console.ReadLine();


        }
    }
}
